﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Conference_BookingBAl;

namespace ConferenceBookingDAL
{
    public class EmployeeDal
    {
        ConferenceBookingDBEntities1 context = new ConferenceBookingDBEntities1();

        public void InsertEmployee(Employeesbal empbal)
        {
            context.sp_InsertEmployee(empbal.EmployeeID, empbal.Password, empbal.EmployeeFname, empbal.EmployeeLname,
                empbal.EmpType, empbal.EmpLocation, empbal.Email, empbal.Notification);
        }
        public void UpdateEmployees(int EmployeeID,string Password, string EmployeeFname, string EmployeeLname, 
            string EmpType, string EmpLocation,string Email,string Notification)
        {
            context.sp_UpdateEmployees(EmployeeID, Password, EmployeeFname, EmployeeLname, EmpType,EmpLocation,Email,Notification);
        }

        //public void UpdateEmployees(Employeesbal empbal)
        //{
        //    throw new NotImplementedException();
        //}
        //public void UpdateEmployeeType(int EmployeeID, string EmployeeType)
        //{
        //    context.sp_UpdateEmployeeType(EmployeeID, EmployeeType);
        //}
        //public void  UpdatePassword(int EmployeeID, string Password)
        //{
        //    context.sp_updatepassword(Password, EmployeeID);
        //}
        //public void UpdateNotification(int EmployeeID, string Notification)
        //{
        //    context.sp_UpdateNotification(EmployeeID, Notification);
        //}
        //public void UpdateEmail(int EmployeeID, string Email)
        //{
        //    context.sp_UpdateEmail(EmployeeID, Email);
        //}
        //public void UpdateLocation (int EmployeeID,string EmpLocation)
        //{
        //    context.sp_UpdateLocation(EmployeeID, EmpLocation);
        //}
        public List<Employee> GetEmployee()
        {
            IQueryable<fn_showEmployees_Result> emplist = context.fn_showEmployees();
            List<fn_showEmployees_Result> Employees = emplist.ToList<fn_showEmployees_Result>();
            List<Employee> empdatalist = new List<Employee>();
            foreach (var item in Employees)
            {
                Employee emp = new Employee();
                emp.EmployeeID = item.EmployeeID;
                emp.Password = item.Password;
                emp.EmployeeFname = item.EmployeeFname;
                emp.EmployeeLname = item.EmployeeLname;
                emp.EmpType = item.EmpType;
                emp.EmpLocation = item.EmpLocation;
                emp.Email = item.Email;
                emp.Notification = item.Notification;
                empdatalist.Add(emp);
                    }
            return empdatalist;
            
        }
        public List<Employee> GetEmployeeById(int id)
        {
            IQueryable<fn_SearchEmployeeById_Result> emplist = context.fn_SearchEmployeeById(id);
            List<fn_SearchEmployeeById_Result> Employees = emplist.ToList<fn_SearchEmployeeById_Result>();
            List<Employee> empdatalist = new List<Employee>();
            foreach (var item in Employees)
            {
                Employee emp = new Employee();
                emp.EmployeeID = item.EmployeeID;
                emp.Password = item.Password;
                emp.EmployeeFname = item.EmployeeFname;
                emp.EmployeeLname = item.EmployeeLname;
                emp.EmpType = item.EmpType;
                emp.EmpLocation = item.EmpLocation;
                emp.Email = item.Email;
                emp.Notification = item.Notification;
                empdatalist.Add(emp);
            }
            return empdatalist;

        }
        public void DeleteEmployees(int EmployeeID)
        {
            context.sp_DeleteEmployee(EmployeeID);
        }

    }
}
