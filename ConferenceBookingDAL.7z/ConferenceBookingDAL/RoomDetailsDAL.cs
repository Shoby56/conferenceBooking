﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Conference_BookingBAl;

namespace ConferenceBookingDAL
{
  public  class RoomDetailsDAL
    {
        ConferenceBookingDBEntities1 context = new ConferenceBookingDBEntities1();
        public void InsertRoomDetails(RoomDetailbal roombal)
        {
            context.sp_insertRoom(roombal.RoomID, roombal.FacilityType,
                roombal.RoomName, roombal.RoomType, roombal.RoomCapacity, roombal.RoomLocation, roombal.Coordinatorid);
        }
        public void UpdateRoomDetail(int RoomID, string FacilityType,string RoomName,string RoomType,int RoomCapacity,string RoomLocation,int Coordinatorid )
        {
            context.sp_UpdateRoomDetails(RoomID, FacilityType, RoomName, RoomType, RoomCapacity, RoomLocation, Coordinatorid);
        }
        public List<RoomDetail> GetRoomsById(int id)
        {
            IQueryable<fn_roomdetailsbyroomid_Result> roomlist = context.fn_roomdetailsbyroomid(id);
            List<fn_roomdetailsbyroomid_Result> RoomDetail = roomlist.ToList<fn_roomdetailsbyroomid_Result>();
            List<RoomDetail> roomdatalist = new List<RoomDetail>();
            foreach (var item in RoomDetail)
            {
                RoomDetail room = new RoomDetail();
                room.RoomID = item.RoomID;
                room.FacilityType = item.FacilityType;
                room.RoomName = item.RoomName;
                room.RoomType = item.RoomType;
                room.RoomCapacity = item.RoomCapacity;
                room.RoomLocation = item.RoomLocation;
                room.Coordinatorid = item.Coordinatorid;
                roomdatalist.Add(room);
            }
            return roomdatalist;
        }
        public List<RoomDetail> GetRooms()
        {
            IQueryable<fn_ShowRoomDetails_Result> roomlist = context.fn_ShowRoomDetails();
            List<fn_ShowRoomDetails_Result> RoomDetail = roomlist.ToList<fn_ShowRoomDetails_Result>();
            List<RoomDetail> roomdatalist = new List<RoomDetail>();
            foreach (var item in RoomDetail)
            {
                RoomDetail room = new RoomDetail();
                room.RoomID = item.RoomID;
                room.FacilityType = item.FacilityType;
                room.RoomName = item.RoomName;
                room.RoomType = item.RoomType;
                room.RoomCapacity = item.RoomCapacity;
                room.RoomLocation = item.RoomLocation;
                room.Coordinatorid = item.Coordinatorid;
                roomdatalist.Add(room);
            }
            return roomdatalist;
        }
        public void DeleteRooms(int RoomID)
        {
            context.Sp_deleteRoom(RoomID);
        }

    }
}
 