﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Conference_BookingBAl;

     
namespace ConferenceBookingDAL
{
  public class FacilityDAL
    { 
        ConferenceBookingDBEntities1 context = new ConferenceBookingDBEntities1();
    public void InsertRoomFacility(RoomFacilitiesbAL facbal)
        {
            context.sp_InsertRoomFacility(facbal.FaciltyType,facbal.TableType,facbal.Videocon,facbal.Phonecon,facbal.WhiteBoard,facbal.FlipChart,facbal.Screen,facbal.Projector,facbal.Network,facbal.Internet,facbal.Machines);
        }
        public void UpdateRoomFacility(string FacilityType, string TableType, bool Videocon, bool Phonecon, bool WhiteBoard, bool FlipChart, bool Screen, bool Projector, bool Network, bool Internet, bool Machines)
        {
            context.sp_UpdateRoomfacility(FacilityType, TableType, Videocon, Phonecon, WhiteBoard, FlipChart, Screen, Projector, Network, Internet, Machines);

        }
       
    }
}
