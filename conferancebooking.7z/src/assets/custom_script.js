function view_booking_history() {
    console.log('hello');
    $('#show_booking_details').modal('show');
}