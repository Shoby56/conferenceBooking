import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './poweruser/home/home.component';
import { NavbarAComponent } from './admin/navbar/navbar.component';
import { NavbarSComponent } from './superuser/navbar/navbar.component';
import { NavbarPComponent } from './poweruser/navbar/navbar.component'
import { BookingHistoryComponent } from './poweruser/booking-history/booking-history.component';
import { SuperhomeComponent } from './superuser/superhome/superhome.component';
import { FullbookinghistoryComponent } from './superuser/fullbookinghistory/fullbookinghistory.component';
import { AdminhomeComponent } from './admin/adminhome/adminhome.component';
import { FullroomdetailsComponent } from './admin/fullroomdetails/fullroomdetails.component';
import { EmployeeComponent } from './superuser/employee/employee.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { from } from 'rxjs';
import { LoginComponent } from './login/login.component';
import { StorageServiceModule } from 'angular-webstorage-service'

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NavbarAComponent,
    NavbarSComponent,
    NavbarPComponent,
    BookingHistoryComponent,
    SuperhomeComponent,
    FullbookinghistoryComponent,
    AdminhomeComponent,
    FullroomdetailsComponent,
    EmployeeComponent,
    LoginComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    StorageServiceModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
