import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {BookingHistoryComponent} from './poweruser/booking-history/booking-history.component'
import { from } from 'rxjs';
import { LoginComponent } from './login/login.component';
import { SuperhomeComponent } from './superuser/superhome/superhome.component';
import { AdminhomeComponent } from './admin/adminhome/adminhome.component';
import { HomeComponent } from './poweruser/home/home.component';
import { FullbookinghistoryComponent } from './superuser/fullbookinghistory/fullbookinghistory.component';
import { EmployeeComponent } from './superuser/employee/employee.component';


const routes: Routes = [

  {path: '', redirectTo: 'EmployeeDetails', pathMatch:'full'},
  {path: 'Login', component: LoginComponent},
  {path: 'Superuser', component: SuperhomeComponent},
  {path: 'Admin', component: AdminhomeComponent},
  {path: 'User', component: HomeComponent},
  {path: 'BookingHistory', component: BookingHistoryComponent},
  {path: 'SuperuserBookingHistory', component: FullbookinghistoryComponent },
  {path: 'EmployeeDetails', component: EmployeeComponent},




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
