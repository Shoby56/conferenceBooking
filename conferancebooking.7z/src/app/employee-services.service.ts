import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './models/EmployeeModel';

@Injectable({
  providedIn: 'root'
})
export class EmployeeServicesService {

  _employee: Employee;
  _employee_output_string: any;
  _somedata;

  constructor(public http: HttpClient) { }

  get_employee() {
    return this.http.get('http://localhost:62118/api/EmployeeTable');
  }

  get_single_employee(_id: number) {
    return this.http.get('http://localhost:62118/api/EmployeeTable/'+_id);
  }

  put_employee(_updatedemploye: Employee) {
    console.log("inside put");
    this.http.put('http://localhost:62118/api/EmployeeTable/' + _updatedemploye.EmployeeID, _updatedemploye).subscribe(r => this._somedata = r);
    console.log("ending put");

  }

}
