import { Component, OnInit } from '@angular/core';
import { BookingService } from 'src/app/booking.service';
import { HttpClient } from '@angular/common/http';
import {Booking} from '../../models/BookingModel'
import { from } from 'rxjs';

@Component({
  selector: 'app-superhome',
  templateUrl: './superhome.component.html',
  styleUrls: ['./superhome.component.css']
})
export class SuperhomeComponent implements OnInit {

  _bookingdata: any;
  _bookingdata_single: any;
  _status_1: boolean;
  _status_2: boolean;
  _status_3: boolean;
  _booking_model: Booking;


  constructor(public _booking_obj: BookingService, public http: HttpClient) {}

  select_booking_single(id: number){
    this._bookingdata.forEach(element => {
      if(element.BookingID == id){
        console.log(element);
        this._bookingdata_single = element;
        if(element.BookingStatus == 'confirm'){
          console.log(element);
          this._status_1 = false;
          this._status_2 = true;
          this._status_3 = false;
          // this._bookingdata_single = element;
        } 
        else if(element.BookingStatus == 'pending'){
          this._status_1 = true;
          this._status_2 = false;
          this._status_3 = false;
        }
        else if(element.BookingStatus == 'cancled'){
          this._status_1 = false;
          this._status_2 = false;
          this._status_3 = true;

        }
      }
    });

  }

  update_booking(bookingstatus :string){
    console.log(this._bookingdata_single.BookingID);
    console.log(bookingstatus);
    

    this._booking_model = new Booking();
    // Update link here
    this._booking_model.BookingStatus = bookingstatus;
     this.http.put('http://localhost:62118/api/BookingConference/'+this._bookingdata_single.BookingID, this._booking_model).subscribe();

  }

  ngOnInit() {
    this.http.get('http://localhost:62118/api/BookingConference/Getdata/').subscribe(
      data => 
      { this._bookingdata = data;
        console.log(data);
     });
  }

}
