import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-fullbookinghistory',
  templateUrl: './fullbookinghistory.component.html',
  styleUrls: ['./fullbookinghistory.component.css']
})
export class FullbookinghistoryComponent implements OnInit {

  _bookingdata: any;
  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get('http://localhost:62118/api/BookingConference/Getdata/').subscribe(
      data => 
      { this._bookingdata = data;
        console.log(data);
     });
  }

}
