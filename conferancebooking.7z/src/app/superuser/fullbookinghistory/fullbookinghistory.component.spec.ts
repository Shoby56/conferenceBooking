import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FullbookinghistoryComponent } from './fullbookinghistory.component';

describe('FullbookinghistoryComponent', () => {
  let component: FullbookinghistoryComponent;
  let fixture: ComponentFixture<FullbookinghistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FullbookinghistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FullbookinghistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
