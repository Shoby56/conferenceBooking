import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-s-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarSComponent implements OnInit {

  constructor() { }
  key: any;

  signout(){
    this.key = localStorage.getItem("userid");
    console.log(this.key);
    localStorage.removeItem("EmployeeID");
    localStorage.removeItem("EmpType");
    localStorage.removeItem("EmpLocation");
    localStorage.removeItem("EmployeeID");

    window.location.href = "/Login";
  }
  ngOnInit() {
    if(!localStorage.getItem("EmployeeID"))
    {
     window.location.href = "/Login" 
    }
  }

}
