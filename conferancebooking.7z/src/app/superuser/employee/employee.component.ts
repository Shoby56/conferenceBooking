import { Component, OnInit } from '@angular/core';
import { EmployeeServicesService } from '../../employee-services.service';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../../models/EmployeeModel'
import { from } from 'rxjs';
import { element } from 'protractor';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  _employeedata: any;
  _single_employeedata: any;
  _employee: Employee;
  _updateddata:any;
  _olddata:any;

  constructor(private _employee_obj: EmployeeServicesService) { }


  add_employee(add_employeedata: any){
    console.log(add_employeedata._new_employeeid);
    console.log(add_employeedata);
  }


  edit_employee(view_employeedata: any) {
    console.log(this._employeedata);

    console.log(typeof(view_employeedata._EmployeeID));
    console.log(view_employeedata);

    this._employee = new Employee();
    this._employee.EmployeeID = view_employeedata._EmployeeID;
    this._employee.Password = this._single_employeedata.Password;
    this._employee.EmployeeFname = view_employeedata._EmployeeFname;
    this._employee.EmployeeLname = view_employeedata._EmployeeLname;
    this._employee.EmpType = view_employeedata._EmpType;
    this._employee.EmpLocation = view_employeedata._EmpType;
    this._employee.Email = this._single_employeedata.Email;
    this._employee.Notification = this._single_employeedata.EmpType;
  

    console.log("=============>");
    this._employee_obj.put_employee(this._employee);

  }

  select_employee(_employee_id: number) {
    console.log(_employee_id);
    console.log(this._employeedata);

    console.log('--------');
    this._employeedata.forEach(element => {
      if (element.EmployeeID == _employee_id) {
        this._single_employeedata = element;
      }
    });
  }

  ngOnInit() {
    this._employeedata = this._employee_obj.get_employee().subscribe(data => { this._employeedata = data });
  }

}
