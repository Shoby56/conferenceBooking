import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Booking } from './models/BookingModel';

@Injectable({
  providedIn: 'root'
})
export class BookingService {

  _booking: Booking;
  _booking_output_string: any;
  _somedata;

  constructor(public http: HttpClient) { }

  get_booking(){
    return this.http.get('http://localhost:62118/api/BookingConference/Getdata/');
  }

  // get_single_employee(_id: number) {
  //   return this.http.get('http://localhost:62118/api/EmployeeTable/'+_id);
  // }

  // put_employee(_updatedbooking: Booking) {
  //   console.log("inside put");
  //   this.http.put('http://localhost:62118/api/EmployeeTable/' + _updatedemploye.EmployeeID, _updatedemploye).subscribe(r => this._somedata = r);
  //   console.log("ending put");

  // }

}
