import { Component, OnInit } from '@angular/core';
import { EmployeeServicesService } from '../employee-services.service'
import { from } from 'rxjs';
import { Employee } from '../models/EmployeeModel';
import { HttpClient } from '@angular/common/http';
import { LocalstorageService } from '../localstorage.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loging_data: any;
  status: boolean;
  emps;
  loginstatus: any;

  constructor(private _loging_obj: EmployeeServicesService, private htttp: HttpClient) { }

  checklogin(userloging: any) {
    console.log(userloging.employeid);
    // alert(localStorage.getItem("userdata"));

    this.htttp.get('http://localhost:62118/api/EmployeeTable/' + userloging.employeid).subscribe(r => this.loging_data = r);

    if (this.loging_data) {
      if (this.checkuser(userloging.password)) {
        localStorage.setItem("EmployeeID", this.loging_data[0].EmployeeID);
        localStorage.setItem("EmpType", this.loging_data[0].EmpType);
        localStorage.setItem("EmpLocation", this.loging_data[0].EmpLocation);
        if (this.loging_data[0].EmpType == 'SA') {
          window.location.href = '/Superuser';
        }
        else if (this.loging_data[0].EmpType == 'AD') {
          window.location.href = '/Admin';
        }
        else if (this.loging_data[0].EmpType == 'PU') {
          window.location.href = '/User';
        }
      }
      else {
        alert("Please Enter correct LOGIN CREDENTIALS");
      }
    }


  }

  checkuser(pass: string) {
    if (this.loging_data[0].Password == pass) {
      this.status = true;
    } else {
      this.status = false;
    }
    return this.status;
  }

  ngOnInit() {
    console.log(localStorage.getItem("EmployeeID"));
    if (localStorage.getItem("EmployeeID")) {
      if (localStorage.getItem("EmpType") == 'SA') {
        window.location.href = '/Superuser';
      }
      else if (localStorage.getItem("EmpType") == 'AD') {
        window.location.href = '/Admin';
      }
      else if (localStorage.getItem("EmpType") == 'PU') {
        window.location.href = '/User';
      }
    }
  }

}
