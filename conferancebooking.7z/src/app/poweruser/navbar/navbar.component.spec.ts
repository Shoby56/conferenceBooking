import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavbarPComponent } from './navbar.component';

describe('NavbarComponent', () => {
  let component: NavbarPComponent;
  let fixture: ComponentFixture<NavbarPComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavbarPComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarPComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
