import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fullroomdetails',
  templateUrl: './fullroomdetails.component.html',
  styleUrls: ['./fullroomdetails.component.css']
})
export class FullroomdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
