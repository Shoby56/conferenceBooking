import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FullroomdetailsComponent } from './fullroomdetails.component';

describe('FullroomdetailsComponent', () => {
  let component: FullroomdetailsComponent;
  let fixture: ComponentFixture<FullroomdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FullroomdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FullroomdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
