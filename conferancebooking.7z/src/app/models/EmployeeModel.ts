export class Employee{
    EmployeeID:number;
    Password:string;
    EmployeeFname:string;
    EmployeeLname:string;
    EmpType:string;
    EmpLocation:string;
    Email:string;
    Notification:string
}