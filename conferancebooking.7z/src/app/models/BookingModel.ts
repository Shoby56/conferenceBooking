export class Booking{
    BookingID: number;
    EmployeeID: number;
    RoomID: number;
    BookingDate: Date;
    StartTime: string;
    EndDate: Date;
    EndTime: string;
    Location: string; 
    BookingStatus: string
}